from Crypto.Util.number import getPrime, bytes_to_long
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from hashlib import sha256
import os, base64, random
from math import gcd

e = 65537
LCG_A, LCG_B, LCG_MOD = 1103515245, 12345, 10007
SECRET_VALUE = 1234

password = f"{random.randint(0,999999):06d}"
salt = os.urandom(8).hex()
hash_val = sha256((salt + password).encode()).hexdigest()

def gen_seq(seed,a,b,m,length):
    seq=[seed % m]
    for _ in range(length-1):
        nxt=(a*seq[-1]+b) % m
        nxt ^= (seq[-1] & 0xff)
        seq.append(nxt)
    return seq

lcg_seed = (int(password) ^ SECRET_VALUE) % LCG_MOD
seq = gen_seq(lcg_seed, LCG_A, LCG_B, LCG_MOD, 15)
seq_prefix = seq[:7]  
seq9 = seq[9]

BITS = 256
p = getPrime(BITS)
q = getPrime(BITS)
n = p * q
n1 = p * (q + 1)
n2 = (p + 1) * q + seq9   

aes_key = os.urandom(16)
mask_bytes = sha256(str(seq9).encode()).digest()[:16]
masked_key_int = bytes_to_long(aes_key) ^ bytes_to_long(mask_bytes)

cipher_rsa = pow(masked_key_int, e, n)

FLAG = b"flag{7980dd68-c028-439d-8f33-3b4e4cfeeb55}"
iv = os.urandom(16)
cipher = AES.new(aes_key, AES.MODE_CBC, iv)
ct = cipher.encrypt(pad(FLAG,16))


print("salt:", salt)
print("hash:", hash_val)
print("n1:", n1)
print("n2:", n2)
print("seq_prefix:", ",".join(str(x) for x in seq_prefix))
print("cipher_rsa:", cipher_rsa)
print("iv:", base64.b64encode(iv).decode())
print("ciphertext:", base64.b64encode(ct).decode())
'''
salt: f62b3e49c1f05d1c
hash: a0bcbfda9bd2f0364c6f4ad0f996465bec0da2de8cd51ee11c9c883b47779cc4
n1: 5584300989285538211153365890789627571870624311506728764237201442331520767215704903718501881100700113185783404202199758018541582967691088869854375384182438
n2: 5584300989285538211153365890789627571870624311506728764237201442331520767215684679677759040755449786845864086748368453212978360679736956915595159857669375
seq_prefix: 2993,3261,4284,5322,6307,1211,8690
cipher_rsa: 4516247026166659285144948330256302160375394741001987438893860039618683568332625137344822301939534363324551681121344467717871483193109869787946141254659256
iv: G+Mn2WPXhRztrDdD8m+1gw==
ciphertext: j9mUOuK2iz9ZHZor8BcsXNFhFRGzkw1x4a5T1GzaYJJ8VhHj+7jN0Id47fcxw/7F
'''
