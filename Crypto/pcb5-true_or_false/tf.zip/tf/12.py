import json, random, hashlib
from Crypto.Util.number import getPrime, inverse, bytes_to_long, long_to_bytes

A=1103515245
B=12345
MOD=2**31

def lcg(s):
    while True:
        s=(A*s+B)%MOD
        yield s&0xFF

def mix(b,s):
    g=lcg(s)
    o=bytearray()
    for i in range(0,len(b),8):
        t=b[i:i+8][::-1]
        for x in t:
            o.append(x^next(g))
    return bytes(o)

BITS=512
e=65537
p=getPrime(BITS)
q=getPrime(BITS)
n=p*q
phi=(p-1)*(q-1)
d=inverse(e,phi)

FLAG=b"flag{de5b8aec-6294-42dd-8038-18e0854e3d22}"
m=bytes_to_long(hashlib.sha256(FLAG).digest())
flag_enc=bytes_to_long(FLAG)^m

sig_ok=pow(m,d,n)

d_p=d%(p-1)
d_q=d%(q-1)
s_p=pow(m,d_p,p)
s_q=random.randrange(q)
inv= inverse(q,p)
sig_fault=(s_q+q*((s_p-s_q)*inv%p))%n

seed=random.randrange(1,2**31)
cj={
    "n":hex(n),
    "e":e,
    "sig_ok_mixed":mix(long_to_bytes(sig_ok),seed).hex(),
    "sig_fault_mixed":mix(long_to_bytes(sig_fault),seed+123456).hex(),
    "flag_enc":hex(flag_enc),
    "seed_hint":seed%97
}

json.dump(cj,open("challenge.json","w"),indent=0)
